/*
 * Homework #2
 * Due Date: 2/11/19
 * Names: Jared Elliot & Timothy Rodriguez
 */
package hangman;

/**
 *
 * @author m14wo
 */
public class Hangman {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
